package com.capg.service;

import com.capg.model.Products;

public interface IProductService {
	public Products addProduct(Products p);

}
