package com.cap.anurag.service;

public interface EmployeeService {

	void deleteEmployeeById(Integer id);

}
